$("#contactform").submit(function (e) {
    e.preventDefault();
    // to stop the redirection of the html

    $('.dropdown-menu');
    console.log(ropdown-menu);


 // -- Récupération des champs du Formulaire
 const nomDesChats     = $('.dropdown-menu');
 const message   = $('.message');


 // -- Validation du choix du chat- Verifier si un des noms des chats est séléctionné autre que "séléctionner"
 if (nomDesChats.val()  ) { 

     
    


}); // -- Fin du Submit()

}); // -- $()

//  PAS DU TOUT FAIT!!! IDEES EMBROUILLEES!!! NEVER MIND!! :( 
